function whosPaying(names) {
    
/******Don't change the code above*******/
    
    //Write your code here.
    
    
    
    


/******Don't change the code below*******/    
}