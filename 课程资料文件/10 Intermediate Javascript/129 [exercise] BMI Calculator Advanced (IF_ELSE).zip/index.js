function bmiCalculator (weight, height) {
    return interpretation;
}